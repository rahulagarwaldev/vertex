#!/bin/sh
rm -fr build/
./gradlew clean build "$@"
