#!/bin/sh
docker stop mysqlvertexwidget
docker rm -f mysqlvertexwidget