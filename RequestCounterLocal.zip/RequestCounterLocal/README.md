# Vertex Backend Interview Project

Hello! In this exercise, you will complete a java microservice using the Spring Boot 
Web MVC framework and spring data.

## Instructions

Complete the service so that your endpoint can perform the following.

1) Create a Widget data type
2) Update a Widget data type
3) Keep track of the number of times each endpoint has been called while this
  server has been alive (should not be stored in DB). (Note: The widget create/update should persist, but the count value per request should not.)
4) Get the total number of requests that have come in while this server has
  been alive. 

Be sure to unit test your controller and service and 
run the integration test below to make sure it handles concurrency.


### System Requirements

These instructions assume you are using an os x/linux based machine for the .sh files.  
For windows you should still be able to execute the commands in the sh files.  Java and Python3 are used.

### Run the server

Once you are ready, use the start.sh script to start the server and the mysql server.

```$ ./start.sh ```

hit control + c to break out of the server (you still need to use stop below for the mysql server.)

You can stop it with

```$ ./stop.sh ```

### Run the integration test

You will need python3. This will create a directory ‘vertexwidgetenv’ in current directory

```$ python3 -m venv vertexwidgetenv```

Then activate your virtual env

```$ source vertexwidgetenv/bin/activate```

Install requests

```$ pip3 install requests```

Start the server first, then run the integrationtests.py

```$ python3 integrationtest.py```

To deactivate the virtual env when you are done

```$ deactivate```

## Submitting

1. Create a **private** Github repo and push your changes.
2. Add the following collaborators to the project

- [`mikewesner`](github.com/mikewesner)
- [`brentav`](github.com/brentav)

4. Send an email to recruiting to notify them that you're finished with the
   project.