#!/bin/sh
docker run --name mysqlvertexwidget -p 3306:3306 -e MYSQL_ROOT_PASSWORD=root -d mysql:5.6
gradle clean build run


