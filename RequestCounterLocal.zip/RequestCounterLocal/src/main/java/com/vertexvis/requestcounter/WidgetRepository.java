package com.vertexvis.requestcounter;

import org.springframework.data.jpa.repository.JpaRepository;

// TODO set this up as JPA repository.
public interface WidgetRepository extends JpaRepository<Widget, Long>{
	 
	 
}
