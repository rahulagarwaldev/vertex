package com.vertexvis.requestcounter.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class WebConfig {

}
