package com.vertexvis.requestcounter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class WidgetService {

    @Autowired
    WidgetRepository widgetRepo;

    public Widget persistWidget(Widget widget) {
        return widgetRepo.save(widget);
    }

    public Widget getWidgetById(Long id) {
        return widgetRepo.findById(id).get();
    }
    
    public Long getWidgetAllCount() {
        return widgetRepo.count();
    }

}
