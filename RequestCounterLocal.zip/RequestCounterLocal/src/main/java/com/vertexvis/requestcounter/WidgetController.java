package com.vertexvis.requestcounter;

import java.util.concurrent.atomic.AtomicLong;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WidgetController {

    @Autowired
    WidgetService widgetService;

    private final AtomicLong getCounter = new AtomicLong(0);
    private final AtomicLong postCounter = new AtomicLong(0);
    private final AtomicLong putCounter = new AtomicLong(0);

    @PostMapping(path = "/widget", consumes = "application/json", produces="application/json")
    public ResponseEntity<Widget> createWidget(@RequestBody Widget widget) {
    	postCounter.incrementAndGet();
        return new ResponseEntity<>(widgetService.persistWidget(widget), HttpStatus.OK);
    }

    @PutMapping(path = "/widget", consumes = "application/json", produces="application/json")
    public ResponseEntity<Widget> updateWidget(@RequestBody Widget widget) {
    	putCounter.incrementAndGet();
    	Widget widgetUpdate = widgetService.getWidgetById(widget.getId()); 	
    	widgetUpdate.setName(widget.getName()); 
    	widgetUpdate.setxPosition(widget.getxPosition());
    	widgetUpdate.setyPosition(widget.getyPosition());
        return new ResponseEntity<>(widgetService.persistWidget(widgetUpdate), HttpStatus.OK);
    }

    @GetMapping(path = "/widget/{id:\\d+}", produces="application/json")
    public ResponseEntity<Object> getWidget(@PathVariable Long id) {
    	getCounter.incrementAndGet();
        return new ResponseEntity<>(widgetService.getWidgetById(id), HttpStatus.OK);
    }
    
    @GetMapping(path = "/widget/create/count", produces="application/json")
    public ResponseEntity<Long> createWidgetCount() {
        return new ResponseEntity<>(postCounter.get(), HttpStatus.OK);
    }

    @GetMapping(path = "/widget/get/count", produces="application/json")
    public ResponseEntity<Long> getWidgetCount() {
    	return new ResponseEntity<>(getCounter.get(), HttpStatus.OK); 
    }

    @GetMapping(path = "/widget/update/count", produces="application/json")
    public ResponseEntity<Long> updateWidgetCount() {
    	return new ResponseEntity<>(putCounter.get(), HttpStatus.OK);
    }

    @GetMapping(path = "/widget/all/count", produces="application/json")
    public ResponseEntity<Long> getWidget() {
        return new ResponseEntity<>(putCounter.get() + getCounter.get() + postCounter.get(), HttpStatus.OK);
    }

}
