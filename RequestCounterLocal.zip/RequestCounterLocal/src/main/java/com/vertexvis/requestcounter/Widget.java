package com.vertexvis.requestcounter;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Widget {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private Integer xPosition;
    private Integer yPosition;

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the xPosition
     */
    public Integer getxPosition() {
        return xPosition;
    }

    /**
     * @param xPosition the xPosition to set
     */
    public void setxPosition(Integer xPosition) {
        this.xPosition = xPosition;
    }

    /**
     * @return the yPosition
     */
    public Integer getyPosition() {
        return yPosition;
    }

    /**
     * @param yPosition the yPosition to set
     */
    public void setyPosition(Integer yPosition) {
        this.yPosition = yPosition;
    }

	@Override
	public String toString() {
		return "Widget [id=" + id + ", name=" + name + ", xPosition=" + xPosition + ", yPosition=" + yPosition + "]";
	}
    
    
}
