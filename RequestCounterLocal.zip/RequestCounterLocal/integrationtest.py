import requests
from multiprocessing.pool import ThreadPool
import random
import string

pool_size = 1000
thread_count = 5

put_ = 0
get_ = 0
post_ = 0
count_endpoint_put = 0
count_endpoint_get = 0
count_endpoint_post = 0

all_init_count = int(requests.get("http://localhost:8080/widget/all/count").json())
get_init_count = int(requests.get("http://localhost:8080/widget/get/count").json())
post_init_count = int(requests.get("http://localhost:8080/widget/create/count").json())
put_init_count = int(requests.get("http://localhost:8080/widget/update/count").json())

widgets = []

urls = [
    [requests.get, {}, 'count_endpoint_get'],
    [requests.post, {'json':{'name':''}}, 'count_endpoint_post'],
    [requests.put, {'json':{'name':''}}, 'count_endpoint_put']
]

call_pool = []
for x in range(pool_size):
    x = random.choice(urls)
    m, d, c = x
    if c == 'count_endpoint_get':
        count_endpoint_get += 1
    elif c == 'count_endpoint_post':
        count_endpoint_post += 1
    elif c == 'count_endpoint_put':
        count_endpoint_put += 1
    call_pool.append(x)


def fetch_url(call):
    try:
        method, args, inc = call
        if inc == 'count_endpoint_post':
            url = "http://localhost:8080/widget"
            args['json']['name'] = ''.join(random.choice(string.ascii_letters) for x in range(8))
            args['json']['xPosition'] = random.randint(1,100)
            args['json']['yPosition'] = random.randint(1,100)
        elif inc == 'count_endpoint_get':
            if len(widgets) > 0:
                url = "http://localhost:8080/widget/" + str(random.choice(widgets)['id'])
            else:
                # no widgets written yet, so don't do a get call
                return 'skip', inc
        elif inc == 'count_endpoint_put':
            url = "http://localhost:8080/widget"
            if len(widgets) > 0:
                w = random.choice(widgets)
                args['json'] = w
            else:
                return 'skip', inc
        response = method(url, **args)
        return response.json(), inc
    except Exception as e:
        print(e)
        return '', inc

print("Running Test!")
results = ThreadPool(thread_count).imap_unordered(fetch_url, call_pool)
for json, incvar in results:
    if incvar == 'count_endpoint_get':
        if (json != 'skip'):
            get_ += 1
    elif incvar == 'count_endpoint_post':
        widgets.append(json)
        post_ += 1
    elif incvar == 'count_endpoint_put':
        if (json != 'skip'):
            put_ += 1


print("Assessing Results...")


all_count = int(requests.get("http://localhost:8080/widget/all/count").json())
get_count = int(requests.get("http://localhost:8080/widget/get/count").json())
post_count = int(requests.get("http://localhost:8080/widget/create/count").json())
put_count = int(requests.get("http://localhost:8080/widget/update/count").json())

print(f"Got total={all_count - all_init_count} get={get_count - get_init_count} post={post_count - post_init_count} put={put_count - put_init_count}")
print(f"Expecting total={get_ + post_ + put_} get={get_} post={post_} put={put_}")
assert(get_count - get_init_count == get_)
assert(post_count - post_init_count == post_)
assert(put_count - put_init_count == put_)
assert(put_ + post_ + get_ + all_init_count == all_count)

print("Test Successful!")
